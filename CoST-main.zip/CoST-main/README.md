CoST(Co-occurrence Spatial-Temporal Model) for backgroud initialization
This apprach is proposed by Dr.ZHOU Wen-jun and Yuheng Deng, it is for background initialization based on CPB.

The files included three parts: 1) CPB for background modeling and foreground detection; 2) Super Pixel segmentation and Motion Mask; 3) Background Initialization.

The code was realized by Dr.ZHOU Wen-jun (zhouwenjun@swpu.edu.cn) and Mr.DENG YU-heng (dengyuhengSWPU@outlook.com) in Image Processing and Parallel Computing Laboratory, School of Computer Science, Southwest Petroleum University, China.


If you need to use it for testing your own algorithm, please feel free to download it.

If you plan to use it in your paper, please tell us in advance.

Thank you.

Oct.1,2021